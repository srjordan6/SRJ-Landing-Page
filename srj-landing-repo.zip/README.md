# SRJ Consulting & Services LLC — Landing Page

Static landing page ready for **Netlify Deploy Previews**.

## Quick Start
1. Create a new GitHub repo: `srj-landing-page`
2. Upload everything in this zip (index.html + assets + netlify.toml)
3. In Netlify: **Add new site → Import from Git → choose your repo**
4. Build command: *(leave blank)*
5. Publish directory: `.`
6. **Deploy**

Any commit or PR will trigger a **Deploy Preview** with a unique URL.
